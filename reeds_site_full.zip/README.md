# Reeds Solutions, LLC Website

This repository contains the static website for Reeds Solutions, LLC.

## Pages
- index.html (Homepage)
- about.html
- capabilities.html
- contracting.html
- contact.html
- thanks.html
- privacy.html
- 404.html

## Deployment
Push to GitHub, Netlify will deploy automatically.