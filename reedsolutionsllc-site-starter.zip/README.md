# Reed Solutions, LLC Website

Static site hosted on Netlify. Update `index.html` and `styles.css` to change content/design.

## Local quick edit
You can edit directly on GitHub (pencil icon) and Netlify will auto-deploy.

## Netlify form handling
The contact form uses Netlify Forms (`data-netlify="true"`). Submissions appear in your Netlify dashboard under **Forms** once the site is live.
